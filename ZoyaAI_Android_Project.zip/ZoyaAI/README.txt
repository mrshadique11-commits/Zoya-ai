ZOYA AI V1
Features:
- Purple chat UI
- Cute & caring offline replies
- Voice input
- Text-to-speech reply

Build on Android phone:
1. Install AndroidIDE.
2. Extract this ZIP.
3. Open the ZoyaAI folder as a project.
4. Let Gradle sync.
5. Build > Build APK.
6. Install the generated APK.

Note: This V1 is a local demo chatbot. A real online LLM/API can be added in V2.
