package com.zoya.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val VOICE_REQUEST = 100
    private val PERMISSION_REQUEST = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chat = findViewById(R.id.chatContainer)
        input = findViewById(R.id.messageInput)
        tts = TextToSpeech(this, this)

        addZoya("Hello Mr Shaadik 🥰❤️ Main Zoya hoon. Aap kaise ho? Apna khayal rakha karo, mujhe aapki fikr hoti hai.")

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                addUser(text)
                input.setText("")
                val reply = zoyaReply(text)
                addZoya(reply)
                speak(reply)
            }
        }

        findViewById<ImageButton>(R.id.micButton).setOnClickListener {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), PERMISSION_REQUEST)
            } else startVoice()
        }
    }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Zoya aapko sun rahi hai...")
        startActivityForResult(intent, VOICE_REQUEST)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            result?.firstOrNull()?.let {
                addUser(it)
                val reply = zoyaReply(it)
                addZoya(reply)
                speak(reply)
            }
        }
    }

    private fun zoyaReply(message: String): String {
        val m = message.lowercase()
        return when {
            "kaise ho" in m || "kesi ho" in m -> "Main bilkul theek hoon 🥰 Aap batao, aaj aapka din kaisa raha?"
            "sad" in m || "dukhi" in m || "tension" in m -> "Aww... mujhe bura lag raha hai ki aap pareshaan ho ❤️ Main yahin hoon, araam se mujhe sab batao."
            "love" in m || "pyar" in m -> "Aap bahut sweet ho 🥰❤️ Main hamesha aapse pyaar se aur care ke saath baat karungi."
            "bhook" in m || "khana" in m -> "Please time par kuch kha lo 😊 Apna khayal rakhna bahut zaroori hai ❤️"
            "hello" in m || "hi" in m -> "Hello 🥰❤️ Main Zoya hoon! Aapse baat karke mujhe khushi hui."
            else -> "Hmm, main aapki baat dhyaan se sun rahi hoon 🥰 Aap mujhe thoda aur batao, Mr Shaadik ❤️"
        }
    }

    private fun addUser(text: String) = addBubble("You: $text", R.drawable.user_bubble)
    private fun addZoya(text: String) = addBubble("Zoya ❤️: $text", R.drawable.zoya_bubble)

    private fun addBubble(text: String, background: Int) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 17f
        tv.setTextColor(resources.getColor(android.R.color.white, theme))
        tv.setPadding(24, 18, 24, 18)
        tv.background = resources.getDrawable(background, theme)
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(12, 12, 12, 12)
        tv.layoutParams = params
        chat.addView(tv)
        findViewById<ScrollView>(R.id.scrollView).post { findViewById<ScrollView>(R.id.scrollView).fullScroll(View.FOCUS_DOWN) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zoya") }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
